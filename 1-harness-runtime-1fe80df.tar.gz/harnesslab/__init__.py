"""Paired harness comparison foundation."""
