"""Best-effort always-step cleanup for this job's exact recorded identities.

No prefix-based deletion and no pruning. A forced job/runner termination can
prevent this step; such a job never supplies a successful qualification result.
"""
import json
from pathlib import Path
import re
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from harnesslab.bounded_process import capture
ROOT=Path(__file__).resolve().parent


def recorded(name, pattern):
    path=ROOT/name
    if not path.exists(): return set()
    if path.is_symlink() or not path.is_file() or path.stat().st_size>16384:
        raise ValueError('Unsafe cleanup marker')
    values=set(path.read_text(encoding='ascii').splitlines())
    if len(values)>64 or any(not re.fullmatch(pattern,value) for value in values):
        raise ValueError('Unsafe cleanup identity')
    return values


def cleanup():
    names=recorded('runtime-owned-containers.txt',r'harness-preflight-[a-f0-9]{32}')
    ids=recorded('runtime-owned-images.txt',r'sha256:[a-f0-9]{64}')
    ids |= recorded('runtime-build.id',r'sha256:[a-f0-9]{64}')
    ids -= recorded('runtime-existing-images.txt',r'sha256:[a-f0-9]{64}')
    for name in names:
        present=capture(['docker','ps','-aq','--filter',f'name=^/{name}$'],timeout_s=10,max_bytes=1024).stdout.strip()
        if present: capture(['docker','rm','--force',name],timeout_s=10,max_bytes=4096)
        if capture(['docker','ps','-aq','--filter',f'name=^/{name}$'],timeout_s=10,max_bytes=1024).stdout.strip():
            raise ValueError('Container cleanup unconfirmed')
    current=set(capture(['docker','image','ls','--no-trunc','--quiet'],timeout_s=10,max_bytes=1024*1024).stdout.decode().splitlines())
    metadata=json.loads((ROOT/'inputs/base-metadata.json').read_text());base=metadata['content_id']
    for value in sorted((ids & current)-{base})+([base] if base in ids & current else []):
        capture(['docker','image','rm','--force',value],timeout_s=20,max_bytes=4096)
    current=set(capture(['docker','image','ls','--no-trunc','--quiet'],timeout_s=10,max_bytes=1024*1024).stdout.decode().splitlines())
    if ids & current: raise ValueError('Image cleanup unconfirmed')
    return {'status':'flask_recorded_identity_cleanup_confirmed','containers_checked':len(names),'images_checked':len(ids)}


if __name__=='__main__':
    try: print(json.dumps(cleanup(),sort_keys=True))
    except Exception: raise SystemExit(3)
