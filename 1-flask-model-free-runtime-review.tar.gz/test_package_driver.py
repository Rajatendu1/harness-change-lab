"""Private package review tests. No Docker, model or network calls."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
import run_qualification as target
from harnesslab.process_observation import KeeperIdentity

BASE = 'sha256:6fd6ebbd05fc4cf5dc3a789c47e42f4d787cb9c90fe5d29835875a934680271d'
BUILT = 'sha256:'+'c'*64
PASS = {'status':'flask_model_free_runtime_controls_passed'}


class PackageDriverTests(unittest.TestCase):
    def invoke(self, fail=None, fail_remove=False):
        ids=set();calls=[]
        metadata=target.load('inputs/base-metadata.json')
        def runner(args,**kwargs):
            calls.append(args)
            if args[:3]==['docker','image','ls']:
                return SimpleNamespace(stdout=('\n'.join(sorted(ids))+'\n').encode() if ids else b'')
            if args[:2]==['docker','pull']:
                ids.add(BASE)
                if fail=='pull':raise ValueError('raw private pull error')
            elif args[:2]==['docker','build']:
                ids.add(BUILT)
                Path(args[args.index('--iidfile')+1]).write_text(BUILT)
                if fail=='build':raise ValueError('raw private build error')
            elif args[:3]==['docker','image','inspect']:
                content = BASE if args[-1].startswith('python@') else BUILT
                env=metadata['config']['Env'] if content==BASE else list(target.expected_environment(metadata['config']['Env'],'verifier'))
                data={'Id':content,'Os':'linux','Architecture':'amd64','Size':1024,
                      'RepoDigests':['python@'+metadata['amd64_manifest_digest']],
                      'Config':{'Env':env}}
                return SimpleNamespace(stdout=json.dumps([data]).encode())
            elif args[:3]==['docker','image','rm']:
                if fail_remove:raise ValueError('removal failed')
                ids.remove(args[-1])
            else:raise AssertionError('Unexpected command')
            return SimpleNamespace(stdout=b'')
        output=io.StringIO()
        for name in ('runtime-owned-containers.txt','runtime-owned-images.txt','runtime-build.id','runtime-existing-images.txt'):
            (target.ROOT/name).unlink(missing_ok=True)
        self.addCleanup(lambda: [(target.ROOT/name).unlink(missing_ok=True) for name in ('runtime-owned-containers.txt','runtime-owned-images.txt','runtime-build.id','runtime-existing-images.txt')])
        with patch.object(target.os,'getuid',return_value=1001),patch.object(target.sys,'argv',['run_qualification.py']),contextlib.redirect_stdout(output):
            code=target.main(runner=runner,qualifier=lambda _:dict(PASS))
        return code,json.loads(output.getvalue()),calls,ids

    def test_success_qualified_only_with_verified_cleanup(self):
        code,result,calls,ids=self.invoke()
        self.assertEqual(code,0);self.assertTrue(result['image_cleanup_confirmed']);self.assertEqual(ids,set())
        self.assertEqual(result['real_provider_calls'],0);self.assertEqual(result['automatic_retries'],0)
        builds=[x for x in calls if x[:2]==['docker','build']]
        self.assertEqual(len(builds),1);self.assertIn('--network=none',builds[0]);self.assertIn('--pull=false',builds[0])

    def test_failed_pull_no_retry_but_new_base_removed(self):
        code,result,calls,ids=self.invoke(fail='pull')
        self.assertEqual(code,3);self.assertEqual(result['stage'],'base_pull');self.assertEqual(ids,set())
        self.assertEqual(len([x for x in calls if x[:2]==['docker','pull']]),1)
        self.assertNotIn('private',json.dumps(result))

    def test_failed_build_cleans_both_known_images(self):
        code,result,_,ids=self.invoke(fail='build')
        self.assertEqual(code,3);self.assertEqual(result['stage'],'verifier_build');self.assertEqual(ids,set())

    def test_cleanup_failure_discards_success(self):
        code,result,_,ids=self.invoke(fail_remove=True)
        self.assertEqual(code,3);self.assertEqual(result['status'],'flask_image_cleanup_unconfirmed');self.assertTrue(ids)

    def test_public_bytes_validate_offline(self):
        base,fixed,narrow,protected=target.task_inputs()
        self.assertEqual(len(base),25);self.assertNotEqual(fixed,base[target.EDITABLE[0]])
        self.assertNotEqual(narrow,base[target.EDITABLE[0]])

    def test_reference_controls_stop_on_first_mismatch_and_remove_probe(self):
        class Adapter:
            name='fake';gid=1001
            removed=False
            def __init__(self,**kwargs):pass
            def create_keeper(self):return KeeperIdentity(12345,1001,65534)
            def call(self,*args,**kwargs):return b'flask-runtime-version-ok\n'
            def verify_denials(self):return b'fixed-denials-ok\n'
            def observe(self):return b'UID PID\n1001 12345\n',{'Running':True,'Paused':False,'Restarting':False,'Dead':False,'Pid':12345,'OOMKilled':False}
            def verify_resource_event(self,probe):return {}
            def remove_and_confirm_absent(self):Adapter.removed=True;return True
        calls=[]
        def score(*args,**kwargs):calls.append(kwargs);return {'passed':True,'tests':1,'skipped':0,'outcome':'reference_verifier_pass'}
        result=target.qualify(None,adapter_factory=Adapter,scorer=score)
        self.assertEqual(result['status'],'flask_reference_controls_unverified');self.assertEqual(len(calls),1)
        self.assertTrue(Adapter.removed)
        self.assertTrue(calls[0]['reference_mode'])


if __name__=='__main__':unittest.main()
