import pytest
import flask

def test_dotted_name_not_allowed(app, client):
    with pytest.raises(ValueError):
        flask.Blueprint("app.ui", __name__)

@pytest.fixture
def app():
    return None

@pytest.fixture
def client():
    return None
