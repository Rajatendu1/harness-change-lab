"""Prepared one-job Flask reference qualification. Not approved to dispatch.

No provider, agent, credential, cache or artifact-upload path. No retries.
Inputs are bundled reviewed public bytes. Only Docker base pull uses network.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import signal
import tempfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from harnesslab.bounded_process import capture
from harnesslab.docker_fixture_adapter import DockerFixtureAdapter
from harnesslab.flask_docker_score import score_flask
from harnesslab.flask_image_plan import validate_verifier_context
from harnesslab.flask_task import validate_base, EDITABLE
from harnesslab.flask_preparation import TEST_HASH
from harnesslab.image_policy import ImagePolicy, validate_image
from harnesslab.offline_build_plan import expected_environment
from harnesslab.process_observation import check_keeper_only


def load(name):
    return json.loads((ROOT / name).read_text())


def task_inputs():
    manifest = load('inputs/source-map.json')
    base = {row['name']:(ROOT/'inputs/base'/row['name']).read_bytes() for row in manifest['base_files']}
    validate_base(base)
    fixed = (ROOT/'inputs/known-fix.py').read_bytes()
    if hashlib.sha256(fixed).hexdigest() != manifest['fixed_source']['sha256']:
        raise ValueError('Fixed source identity mismatch')
    protected = (ROOT/'inputs/protected-test.py').read_bytes()
    if hashlib.sha256(protected).hexdigest() != TEST_HASH:
        raise ValueError('Protected identity mismatch')
    original = base[EDITABLE[0]].decode()
    anchor = '        self.name = name\n'
    if original.count(anchor) != 1:
        raise ValueError('Narrow reference anchor mismatch')
    narrow = original.replace(anchor, '        if "." in name:\n            raise ValueError("Blueprint name must not contain a dot")\n\n' + anchor).encode()
    return base, fixed, narrow, protected


def tracked_adapter(**kwargs):
    adapter = DockerFixtureAdapter(**kwargs)
    if not re.fullmatch(r'harness-preflight-[a-f0-9]{32}', adapter.name):
        raise ValueError('Unexpected tracked container name')
    with (ROOT/'runtime-owned-containers.txt').open('a',encoding='ascii') as stream:
        stream.write(adapter.name + '\n')
    return adapter


def qualify(policy, *, adapter_factory=tracked_adapter, scorer=score_flask):
    """A separate probe keeper, followed by three fresh reference scorers."""
    base, fixed, narrow, protected = task_inputs()
    probe_removed = False
    with tempfile.TemporaryDirectory(prefix='flask-probe-empty-') as directory:
        adapter = adapter_factory(image_policy=policy, socket_directory=directory, gateway_gid=os.getgid())
        try:
            identity = adapter.create_keeper()
            version = adapter.call(['docker','exec','--user',f'65534:{adapter.gid}',adapter.name,
                '/opt/verifier/bin/python','-I','-c',
                'import sys; assert sys.version_info[:3]==(3,10,22); print("flask-runtime-version-ok")'],
                timeout=5,max_bytes=128)
            if version != b'flask-runtime-version-ok\n':
                raise ValueError('Runtime patch version unverified')
            if adapter.verify_denials() != b'fixed-denials-ok\n':
                raise ValueError('Denials unverified')
            check_keeper_only(*adapter.observe(), identity)
            for probe in ('pids','cpu','memory'):
                adapter.verify_resource_event(probe)
        finally:
            probe_removed = adapter.remove_and_confirm_absent() is True
    if not probe_removed:
        raise ValueError('Probe cleanup unconfirmed')
    records = []
    for stage, content, expected in [('unchanged_base',base[EDITABLE[0]],False),
                                    ('known_upstream_fix',fixed,True),('narrow_reference_patch',narrow,True)]:
        candidate = dict(base); candidate[EDITABLE[0]] = content
        row = scorer(candidate, base=base, protected_test=protected, image_policy=policy, reference_mode=True, adapter_factory=adapter_factory)
        records.append({'stage':stage, 'score':row})
        if (row.get('passed') is not expected or row.get('tests') != 1 or row.get('skipped') != 0
                or row.get('outcome') != ('reference_verifier_pass' if expected else 'reference_verifier_fail')):
            return {'status':'flask_reference_controls_unverified', 'records':records}
    return {'status':'flask_model_free_runtime_controls_passed', 'records':records,
            'probe_container_removal_confirmed':probe_removed, 'resource_probes':['pids','cpu','memory'],
            'evidence_class':'public_real_source_reference_controls_not_agent_or_model',
            'adversarial_integrity_verified':False}


def image_ids(runner):
    raw = runner(['docker','image','ls','--no-trunc','--quiet'],timeout_s=10,max_bytes=1024*1024).stdout.decode()
    values = set(raw.splitlines())
    if any(not re.fullmatch(r'sha256:[a-f0-9]{64}', value) for value in values):
        raise ValueError('Unexpected image listing')
    return values


def main(*, runner=capture, qualifier=qualify):
    if len(sys.argv) != 1 or os.getuid() != 1001:
        raise ValueError('Fixed runner identity and no arguments required')
    metadata = load('inputs/base-metadata.json')
    dependencies = load('inputs/wheel-manifest.json')
    helper = load('inputs/verifier-helper-manifest.json')
    reference = 'python@' + metadata['amd64_manifest_digest']
    context = ROOT/'verifier-context'
    validate_verifier_context(context,base_reference=reference,dependency_manifest=dependencies,helper_manifest=helper)
    task_inputs()
    previous = image_ids(runner)
    with (ROOT/'runtime-existing-images.txt').open('x',encoding='ascii') as stream:
        stream.write(''.join(value+'\n' for value in sorted(previous)))
    base_id = metadata['content_id']; created = set()
    for marker in ('runtime-owned-containers.txt','runtime-owned-images.txt'):
        with (ROOT/marker).open('x',encoding='ascii'): pass
    def record_image(content):
        if content not in previous and content not in created:
            created.add(content)
            with (ROOT/'runtime-owned-images.txt').open('a',encoding='ascii') as stream:
                stream.write(content+'\n')
    record_image(base_id)
    stage = 'base_pull'
    result = {'status':'flask_runtime_setup_unverified'}; cleanup = False
    built_verified = False
    try:
        runner(['docker','pull','--platform','linux/amd64',reference],timeout_s=120,max_bytes=2*1024*1024)
        if base_id not in previous: record_image(base_id)
        base_policy = ImagePolicy(reference,base_id,tuple(metadata['config']['Env']),4*1024**3)
        info = json.loads(runner(['docker','image','inspect',reference],timeout_s=10,max_bytes=1024*1024).stdout)
        if not isinstance(info,list) or len(info) != 1: raise ValueError('Base unavailable')
        validate_image(info[0],base_policy)
        stage = 'verifier_build'
        with tempfile.TemporaryDirectory(prefix='flask-image-id-') as temporary:
            iid = ROOT/'runtime-build.id'
            if iid.exists() or iid.is_symlink():
                raise ValueError('Unexpected prior build marker')
            try:
                runner(['docker','build','--network=none','--pull=false','--target','flask-verifier',
                        '--iidfile',str(iid),str(context)],timeout_s=180,max_bytes=2*1024*1024)
            finally:
                if iid.is_file():
                    built = iid.read_text().strip()
                    if re.fullmatch(r'sha256:[a-f0-9]{64}',built) and built not in previous: record_image(built)
            built = iid.read_text().strip()
            if not re.fullmatch(r'sha256:[a-f0-9]{64}',built): raise ValueError('Build identity unavailable')
            policy = ImagePolicy(built,built,expected_environment(metadata['config']['Env'],'verifier'),4*1024**3)
            info = json.loads(runner(['docker','image','inspect',built],timeout_s=10,max_bytes=1024*1024).stdout)
            if not isinstance(info,list) or len(info) != 1: raise ValueError('Built image unavailable')
            validate_image(info[0],policy)
            built_verified = True
            stage = 'runtime_controls'
            result = qualifier(policy)
    except Exception:
        result = {'status':'flask_runtime_setup_or_execution_unverified','stage':stage}
    finally:
        # A completed pull can outlive a failed client command. Inspect the fixed
        # known base ID on cleanup too, without deleting preexisting images.
        inventory_ok = True
        try:
            if base_id not in previous and base_id in image_ids(runner): record_image(base_id)
        except Exception:
            inventory_ok = False
            result = {'status':'flask_cleanup_inventory_unverified','stage':stage}
        removal_ok = True
        for content in sorted(created - {base_id}) + ([base_id] if base_id in created else []):
            try: runner(['docker','image','rm','--force',content],timeout_s=20,max_bytes=4096)
            except Exception: removal_ok = False
        try: cleanup = inventory_ok and removal_ok and not (created & image_ids(runner))
        except Exception: cleanup = False
    result.update(real_provider_calls=0,real_model_repairs=0,agent_runs=0,automatic_retries=0,
                  image_cleanup_confirmed=cleanup,verifier_image_built_and_verified=built_verified,created_image_count=len(created))
    if not cleanup: result['status'] = 'flask_image_cleanup_unconfirmed'
    print(json.dumps(result,sort_keys=True))
    return 0 if result.get('status') == 'flask_model_free_runtime_controls_passed' else 3


if __name__ == '__main__':
    def terminate(signum, frame):
        raise TimeoutError('Job termination requested')
    signal.signal(signal.SIGTERM, terminate)
    raise SystemExit(main())
